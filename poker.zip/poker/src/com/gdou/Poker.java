package com.gdou;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class Poker {
    private Decors decors;
    private Points points;


    public static void main(String[] args) {
        Set<Integer> set = new HashSet<>();
        Random random = new Random();
        int[] ints = new int[52];
        for (int i = 0; i < 52; i++) {
            int i1 = Config.randInt(random, set);
            System.out.print(i1+" ");
            ints[i] = i1;
        }
        System.out.println();
        Arrays.sort(ints);
        System.out.println(Arrays.toString(ints));
    }

    @Override
    public String toString() {
        return "Poker{" +
                "decors=" + decors +
                ", points=" + points +
                '}';
    }

    public Poker() {
    }

    public Poker(Decors decors, Points points) {
        this.decors = decors;
        this.points = points;
    }

    public Decors getDecors() {
        return decors;
    }

    public void setDecors(Decors decors) {
        this.decors = decors;
    }

    public Points getPoints() {
        return points;
    }

    public void setPoints(Points points) {
        this.points = points;
    }
}
