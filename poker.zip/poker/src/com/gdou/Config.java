package com.gdou;

import java.util.*;

public class Config {


    public static void main(String[] args) {
        //1.初始化一个扑克牌列表
        List<Poker> pokers = new ArrayList<>();
        for (int i = 0; i < Decors.values().length; i++) {
            for (int j = 0; j < Points.values().length; j++) {
                pokers.add(new Poker(Decors.values()[i],Points.values()[j]));
            }
        }
        //2.在扑克牌列表中随机发牌，生成四组数组
        Set<Integer> set = new HashSet<>();
        List<List<Poker>> lists = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            lists.add(rand(pokers,set));
        }
        for (List<Poker> list : lists) {
            Collections.sort(list, Comparator.comparing(Poker::getPoints));
        }
        System.out.println(lists);
    }

    public static  List<Poker> rand(List<Poker> pokers,Set<Integer> set){
        List<Poker> list = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < 13; i++) {
            int randInt = randInt(random, set);
            list.add(pokers.get(randInt));
        }
        return list;
    }

    public static int randInt(Random random,Set<Integer> set){
        int rand = random.nextInt(52);//0-51,满足需求
        if (set.contains(rand)){
            return randInt(random,set);
        }
        set.add(rand);
        return rand;
    }
}
