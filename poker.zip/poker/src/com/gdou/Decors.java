package com.gdou;

public enum Decors {
    Heart,Spade,Diamond,Club;
}
