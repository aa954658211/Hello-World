package com.gdou;

public enum Points {
    A,Two,Three,Four,Five,Six,Seven,Eight,Nine,Ten,J,Q,K;
}
