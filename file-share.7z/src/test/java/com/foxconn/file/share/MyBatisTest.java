package com.foxconn.file.share;

import com.foxconn.file.share.service.FileBeanService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author X2001077
 * @time 2021/10/29 17:15
 * @description
 */
@SpringBootTest(classes = Application.class)
@RunWith(SpringRunner.class)
public class MyBatisTest {

    @Autowired
    private FileBeanService fileBeanService;


    @Test
    public void test(){
        System.out.println(fileBeanService.list());
    }

}
