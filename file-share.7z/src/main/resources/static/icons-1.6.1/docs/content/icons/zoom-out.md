---
title: Zoom out
categories:
  - Graphics
tags:
  - minify
  - scale
---
