---
title: Hourglass bottom
categories:
  - Real world
tags:
  - time
  - history
  - wait
  - sand
  - clock
---
