---
title: Pin map
categories:
  - Geo
tags:
  - geography
  - map
  - pin
  - location
---
