---
title: Sticky
categories:
  - Real world
tags:
  - postit
  - note
  - sticky
---
