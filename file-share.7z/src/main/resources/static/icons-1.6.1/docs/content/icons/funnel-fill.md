---
title: Funnel fill
categories:
  - Real world
tags:
  - sort
  - filter
---
