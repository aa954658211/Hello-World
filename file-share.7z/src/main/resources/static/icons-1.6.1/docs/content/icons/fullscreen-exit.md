---
title: Fullscreen exit
categories:
  - UI and keyboard
tags:
  - window
  - minimize
---
