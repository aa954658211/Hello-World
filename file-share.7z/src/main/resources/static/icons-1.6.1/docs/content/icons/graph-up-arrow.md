---
title: Graph up arrow
categories:
  - Data
tags:
  - chart
  - graph
  - analytics
---
