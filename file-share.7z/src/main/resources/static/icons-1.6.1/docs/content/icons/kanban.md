---
title: Kanban
categories:
  - Miscellaneous
tags:
  - board
  - project-management
---
