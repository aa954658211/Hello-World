---
title: Recycle
categories:
  - Arrows
tags:
  - recyling
  - trash
---
