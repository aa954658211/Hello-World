---
title: Scissors
categories:
  - Real world
tags:
  - cut
  - shears
---
