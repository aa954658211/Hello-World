package com.foxconn.file.share.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foxconn.file.share.entity.User;

/**
 * @author X2001077
 * @time 2021/11/2 10:42
 * @description
 */
public interface UserMapper extends BaseMapper<User> {
}