package com.foxconn.file.share.util;

import lombok.extern.slf4j.Slf4j;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.net.URLDecoder;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.WritableByteChannel;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * @author X2001077
 * @time 2021/11/2 11:37
 * @description
 */
@Slf4j
public class FileUtil {

    public static final String DOWNLOAD_TYPE = "download";
    public static final String MASTER_TYPE = "master";
    public static final String DIR_TYPE = "createDir";
    public static final String UPLOAD_TYPE = "upload";
    public static final String UPDATE_TYPE = "update";
    public static final String COMPRESS_TYPE = "compress";

    public static String getDir(HttpServletRequest request, String user, String type) {
        String dir = "";
        try {
            dir = URLDecoder.decode(request.getRequestURI(), "utf-8").replace("/" + type, "")
                    .replaceFirst("/" + user, "");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        if (dir.startsWith("/")) {
            dir = dir.substring(1);
        }
        if (dir.endsWith("/")) {
            dir = dir.substring(0, dir.length() - 1);
        }
        return dir;
    }

    public static void toZip(File sourceFile, OutputStream outputStream) {
        long start = System.currentTimeMillis();
        long end = 0;
//        File sourceFile = new File(dir);
        ZipOutputStream zos = null;
        try {
            zos = new ZipOutputStream(outputStream);
            zos.setLevel(6);
            compressNio(sourceFile, zos, sourceFile.getName());
            end = System.currentTimeMillis();
        } catch (Exception e) {
            throw new RuntimeException("zip error,target dir is " + sourceFile.getName());
        } finally {
            if (zos != null) {
                try {
                    zos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        log.info("压缩完成,目标目录为{},耗时：{}ms", sourceFile.getName(), (end - start));
    }

    public static void compressNio(File sourceFile, ZipOutputStream zos, String name) throws Exception {
        if (sourceFile.isFile()) {
            zos.putNextEntry(new ZipEntry(name));
            ByteBuffer buffer = ByteBuffer.allocate(2048);
            FileInputStream fi = new FileInputStream(sourceFile);
            FileChannel fileChannel = fi.getChannel();
            WritableByteChannel writableByteChannel = Channels.newChannel(zos);
            while (fileChannel.read(buffer) != -1) {
                buffer.flip();
                while (buffer.hasRemaining()) {
                    writableByteChannel.write(buffer);
                }
                buffer.clear();
            }
            fileChannel.close();
            writableByteChannel.close();
            zos.closeEntry();
        } else {
            File[] listFiles = sourceFile.listFiles();
            if (listFiles != null && listFiles.length != 0) {
                for (File listFile : listFiles) {
                    compress(listFile, zos, name + "/" + listFile.getName());
                }
            } else {
                zos.putNextEntry(new ZipEntry(name + "/"));
                zos.closeEntry();
            }
        }
    }

    public static void compress(File sourceFile, ZipOutputStream zos, String name) throws Exception {
        byte[] buffer = new byte[8192];
        if (sourceFile.isFile()) {
            zos.putNextEntry(new ZipEntry(name));
            int len;
            FileInputStream fi = new FileInputStream(sourceFile);
            BufferedInputStream bis = new BufferedInputStream(fi);
            while ((len = bis.read(buffer)) != -1) {
                zos.write(buffer, 0, len);
            }
            zos.closeEntry();
            bis.close();
            fi.close();
        } else {
            File[] listFiles = sourceFile.listFiles();
            if (listFiles != null && listFiles.length != 0) {
                for (File listFile : listFiles) {
                    //需要加/
                    compress(listFile, zos, name + "/" + listFile.getName());
                }
            } else {
                //空文件夹
                zos.putNextEntry(new ZipEntry(name + "/"));
                zos.closeEntry();
            }
        }
    }
}
