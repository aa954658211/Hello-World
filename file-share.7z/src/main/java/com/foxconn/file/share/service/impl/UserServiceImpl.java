package com.foxconn.file.share.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foxconn.file.share.dao.UserMapper;
import com.foxconn.file.share.entity.User;
import com.foxconn.file.share.service.UserService;

/**
 * @author X2001077
 * @time 2021/11/2 10:41
 * @description
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

}

