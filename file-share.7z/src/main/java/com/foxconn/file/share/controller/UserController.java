package com.foxconn.file.share.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.foxconn.file.share.entity.User;
import com.foxconn.file.share.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * @author X2001077
 * @time 2021/11/3 8:28
 * @description
 */
@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Value("${file.basePath}")
    private String basePath;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/register")
    public String register(User user) {
        //加密密码
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userService.save(user);
        //默认开通文件夹
        String username = user.getUsername();
        File file = new File(basePath + username);
        if (!file.exists()) {
            file.mkdirs();
        }
        return "redirect:/login";
    }

    @PostMapping("/check")
    @ResponseBody
    public Map<String, Object> checkUser(String username) {
        User one = userService.getOne(new LambdaQueryWrapper<User>().eq(User::getUsername, username));
        Map<String, Object> map = new HashMap<>();
        if (one != null) {
            map.put("valid", false);
        } else {
            map.put("valid", true);
        }
        return map;
    }
}
