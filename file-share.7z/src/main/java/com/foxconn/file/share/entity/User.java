package com.foxconn.file.share.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Date;

/**
 * @author X2001077
 * @time 2021/11/2 10:42
 * @description
 */
@ApiModel(value = "com-foxconn-file-share-entity-User")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "`user`")
public class User implements UserDetails {
    public static final String COL_SEX = "sex";
    /**
     * 用户主键id
     */
    @TableId(value = "id", type = IdType.INPUT)
    @ApiModelProperty(value = "用户主键id")
    private Integer id;

    /**
     * 用户名
     */
    @TableField(value = "username")
    @ApiModelProperty(value = "用户名")
    private String username;

    /**
     * 用户密码
     */
    @TableField(value = "`password`")
    @ApiModelProperty(value = "用户密码")
    private String password;

    /**
     * 用户姓名
     */
    @TableField(value = "`name`")
    @ApiModelProperty(value = "用户姓名")
    private String name;

    /**
     * 用户手机号（真实的手机号）
     */
    @TableField(value = "mobile")
    @ApiModelProperty(value = "用户手机号（真实的手机号）")
    private String mobile;

    /**
     * 用户邮箱
     */
    @TableField(value = "mail")
    @ApiModelProperty(value = "用户邮箱")
    private String mail;

    /**
     * 角色id
     */
    @TableField(value = "role_id")
    @ApiModelProperty(value = "角色id")
    private Integer roleId;

    /**
     * 用户创建时间
     */
    @TableField(value = "create_time",fill = FieldFill.INSERT)
    @ApiModelProperty(value = "用户创建时间")
    private Date createTime;

    @TableField(value = "last_modified",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty(value = "")
    private Date lastModified;

    public static final String COL_ID = "id";

    public static final String COL_USERNAME = "username";

    public static final String COL_PASSWORD = "password";

    public static final String COL_NAME = "name";

    public static final String COL_MOBILE = "mobile";

    public static final String COL_MAIL = "mail";

    public static final String COL_ROLE_ID = "role_id";

    public static final String COL_CREATE_TIME = "create_time";

    public static final String COL_LAST_MODIFIED = "last_modified";

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return null;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}