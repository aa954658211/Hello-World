package com.foxconn.file.share.config;

import com.foxconn.file.share.security.MyAccessDeniedHandler;
import com.foxconn.file.share.security.MySuccessHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * @author X2001077
 * @time 2021/11/1 8:50
 * @description
 */
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private MySuccessHandler mySuccessHandler;

    @Autowired
    private MyAccessDeniedHandler myAccessDeniedHandler;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService)
                .passwordEncoder(passwordEncoder());
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/icons-1.6.1/**",
                "/editor.md-master/**",
                "/icon/**",
                "/favicon.ico",
                "/js/**",
                "/css/**");
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        String[] SWAGGER_WHITELIST = {
                "/swagger-ui.html",
                "/swagger-ui/*",
                "/swagger-resources/**",
                "/v2/api-docs",
                "/v3/api-docs"
        };
        http.exceptionHandling().accessDeniedHandler(myAccessDeniedHandler);
        http.authorizeRequests()
                .antMatchers(SWAGGER_WHITELIST).permitAll()
//                .antMatchers(
//                        HttpMethod.GET,
//                        "/*.html",
//                        "/**/*.html",
//                        "/**/*.css",
//                        "/**/*.js",
//                        "/**/*.png"
//                ).permitAll()
                .antMatchers("/login").permitAll()
                .antMatchers("/user/**").permitAll()
                .antMatchers("/webjars/**").permitAll()
                .anyRequest().authenticated()
                .and().logout().permitAll()
                .and().formLogin()
                .loginPage("/login").loginProcessingUrl("/login").
                successHandler(mySuccessHandler).permitAll()
                .and().rememberMe()
                .and().csrf().disable();

    }

}
