package com.foxconn.file.share.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.foxconn.file.share.entity.CommonResult;
import com.foxconn.file.share.entity.FileBean;
import com.foxconn.file.share.service.FileBeanService;
import com.foxconn.file.share.util.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

/**
 * @author X2001077
 * @time 2021/11/2 11:37
 * @description
 */
@Controller
public class CommonController {

    @Value("${file.basePath}")
    private String basePath;

    @Autowired
    private FileBeanService fileBeanService;

    @GetMapping("/download/{user}/**")
    public void download(@PathVariable String user, HttpServletRequest request, HttpServletResponse response) throws Exception {
        String dir = FileUtil.getDir(request, user, FileUtil.DOWNLOAD_TYPE);
        File file = new File(basePath + user + "/" + dir);
        if (!file.exists()) {
            response.sendError(404);
            return;
        }
        FileInputStream fileInputStream = new FileInputStream(file);
        ServletOutputStream outputStream = response.getOutputStream();
        BufferedOutputStream bos = new BufferedOutputStream(outputStream);
        response.addHeader("Content-Disposition", "attachment;filename=" + file.getName());
        int len;
        byte[] buffer = new byte[8192];
        while ((len = fileInputStream.read(buffer)) != -1) {
            bos.write(buffer, 0, len);
            bos.flush();
        }
    }

    @PostMapping("/upload/{user}/**")
    @ResponseBody
    @PreAuthorize("@ps.hasPermission()")
    public CommonResult upload(@PathVariable String user, HttpServletRequest request, MultipartFile file, String message) {
        if (file == null) {
            return CommonResult.fail().message("上传文件不能为空!");
        }
        String dir = FileUtil.getDir(request, user, FileUtil.UPLOAD_TYPE);
        File parent = new File(basePath + user + "/" + dir);
        System.out.println(parent);
        String originalFilename = file.getOriginalFilename();
        if (originalFilename != null && originalFilename.contains("\\")) {
            originalFilename = originalFilename.substring(originalFilename.lastIndexOf("\\") + 1);
        }
        File newFile = new File(parent, originalFilename);
        if (newFile.exists()) {
            return CommonResult.fail().message("文件已存在!");
        }
        try {
            file.transferTo(newFile);
            FileBean fileBean = new FileBean();
            fileBean.setName(originalFilename);
            fileBean.setPath(user + "/" + dir);
            fileBean.setType(originalFilename.substring(originalFilename.lastIndexOf(".") + 1));
            fileBean.setOwner(user);
            fileBean.setSize(newFile.length());
            fileBean.setMessage(message);
            fileBean.setShare(1);
            fileBean.setDirectory(0);
            fileBeanService.save(fileBean);
        } catch (Exception e) {
            return CommonResult.fail().message(e.getMessage());
        }
        return CommonResult.success();
    }

    @PostMapping("/createDir/{user}/**")
    @ResponseBody
    @PreAuthorize("@ps.hasPermission()")
    public CommonResult createDir(@PathVariable String user, HttpServletRequest request, FileBean fileBean) {
        String dir = FileUtil.getDir(request, user, FileUtil.DIR_TYPE);
        File parent = new File(basePath + user + "/" + dir);
        File file = new File(parent, fileBean.getName());
        if (!file.exists()) {
            file.mkdirs();
            fileBean.setPath(user + "/" + dir);
            fileBean.setOwner(user);
            fileBean.setDirectory(1);
            fileBean.setShare(1);
            fileBeanService.save(fileBean);
        }
        return CommonResult.success();
    }

    @GetMapping("/share/data")
    @ResponseBody
    public CommonResult getSharedFiles() {
        List<FileBean> list = fileBeanService.list(
                new LambdaQueryWrapper<FileBean>()
                        .eq(FileBean::getShare, 1)
                        .eq(FileBean::getDirectory, 0));
        return CommonResult.success(list);
    }

    @PostMapping("/update/{user}/**")
    @PreAuthorize("@ps.hasPermission()")
    @ResponseBody
    public CommonResult updateShare(@PathVariable String user, boolean share, HttpServletRequest request) {
        String dir = FileUtil.getDir(request, user, FileUtil.UPDATE_TYPE);
        File parent = new File(basePath + user + "/" + dir);
        FileBean fileBean = fileBeanService.getOne(new LambdaQueryWrapper<FileBean>()
                .eq(FileBean::getOwner, user)
                .eq(FileBean::getPath, user + "/")
                .eq(FileBean::getName, parent.getName()));
        if (fileBean != null) {
            fileBean.setShare(share ? 1 : 0);
            try {
                fileBeanService.updateById(fileBean);
            } catch (Exception e) {
                e.printStackTrace();
                return CommonResult.fail();
            }
            return CommonResult.success();
        }
        return CommonResult.fail();
    }

    @GetMapping("/compress/{user}/**")
    @PreAuthorize("@ps.hasPermission()")
    public void compress(@PathVariable String user, HttpServletRequest request, HttpServletResponse response) {
        String dir = FileUtil.getDir(request, user, FileUtil.COMPRESS_TYPE);
        File parent = new File(basePath + user + "/" + dir);
        try {
            response.setHeader("Content-Disposition", "attachment;filename=" + parent.getName() + ".zip");
            FileUtil.toZip(parent, response.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
