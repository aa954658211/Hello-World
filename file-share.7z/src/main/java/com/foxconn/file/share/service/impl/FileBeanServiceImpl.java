package com.foxconn.file.share.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foxconn.file.share.dao.FileBeanMapper;
import com.foxconn.file.share.entity.FileBean;
import com.foxconn.file.share.service.FileBeanService;

/**
 * @author X2001077
 * @time 2021/11/2 8:44
 * @description
 */
@Service
public class FileBeanServiceImpl extends ServiceImpl<FileBeanMapper, FileBean> implements FileBeanService {

}






