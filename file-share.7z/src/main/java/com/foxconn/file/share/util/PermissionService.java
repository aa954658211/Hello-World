package com.foxconn.file.share.util;

import com.foxconn.file.share.entity.User;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * @author X2001077
 * @time 2021/11/3 14:59
 * @description
 */
@Component("ps")
public class PermissionService {

    public boolean hasPermission() {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        String requestURI = request.getRequestURI();
        AntPathMatcher pathMatcher = new AntPathMatcher();
        Map<String, String> map = pathMatcher.extractUriTemplateVariables("/*/{user}/**", requestURI);
        User principal = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal.getUsername().equals(map.get("user"))) {
            return true;
        }
        return false;
    }

}
