package com.foxconn.file.share.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author X2001077
 * @time 2021/11/2 11:42
 * @description
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommonResult {

    private int code;
    private String message;
    private Object data;

    public  CommonResult message(String message){
       this.setMessage(message);
        return this;
    }

    public  CommonResult code(int code){
        this.setCode(code);
        return this;
    }

    public static CommonResult success() {
        return new CommonResult(200, "success", null);
    }

    public static CommonResult success(Object data) {
        return new CommonResult(200, "success", data);
    }

    public static CommonResult fail() {
        return new CommonResult(500, "fail", null);
    }

    public static CommonResult fail(Object data) {
        return new CommonResult(500, "fail", data);
    }
}
