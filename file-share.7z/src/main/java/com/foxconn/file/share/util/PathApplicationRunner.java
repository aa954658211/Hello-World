package com.foxconn.file.share.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.io.File;

/**
 * @author X2001077
 * @time 2021/11/3 17:08
 * @description
 */
@Component
public class PathApplicationRunner implements ApplicationRunner {

    @Value("${file.basePath}")
    private String basePath;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        File file = new File(basePath);
        if (!file.exists()) {
            file.mkdirs();
        }
    }
}
