package com.foxconn.file.share.service;

import com.foxconn.file.share.entity.FileBean;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @author X2001077
 * @time 2021/11/2 8:44
 * @description
 */
public interface FileBeanService extends IService<FileBean> {


}






