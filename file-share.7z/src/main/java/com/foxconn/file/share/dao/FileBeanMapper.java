package com.foxconn.file.share.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foxconn.file.share.entity.FileBean;

/**
 * @author X2001077
 * @time 2021/11/2 15:05
 * @description
 */
public interface FileBeanMapper extends BaseMapper<FileBean> {
}