package com.foxconn.file.share.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @author X2001077
 * @time 2021/11/2 15:05
 * @description
 */
@ApiModel(value = "com-foxconn-file-share-entity-FileBean")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "file_bean")
public class FileBean {
    public static final String COL_CREATETIME = "createTime";
    public static final String COL_LASTMODIFIED = "lastModified";
    public static final String COL_ID = "id";
    public static final String COL_NAME = "name";
    public static final String COL_PATH = "path";
    public static final String COL_TYPE = "type";
    public static final String COL_OWNER = "owner";
    public static final String COL_DIRECTORY = "directory";
    public static final String COL_CREATE_TIME = "create_time";
    public static final String COL_LAST_MODIFIED = "last_modified";
    public static final String COL_SIZE = "size";
    public static final String COL_SHARE = "share";
    @TableId(value = "id", type = IdType.INPUT)
    @ApiModelProperty(value = "")
    private Integer id;

    @TableField(value = "`name`")
    @ApiModelProperty(value = "")
    private String name;

    @TableField(value = "`path`")
    @ApiModelProperty(value = "")
    private String path;

    @TableField(value = "`type`")
    @ApiModelProperty(value = "")
    private String type;

    @TableField(value = "`owner`")
    @ApiModelProperty(value = "")
    private String owner;

    @TableField(value = "directory")
    @ApiModelProperty(value = "")
    private Integer directory;

    @TableField(value = "create_time",fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @ApiModelProperty(value = "")
    private Date createTime;

    @TableField(value = "last_modified",fill = FieldFill.INSERT_UPDATE)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @ApiModelProperty(value = "")
    private Date lastModified;

    @TableField(value = "`size`")
    @ApiModelProperty(value = "")
    private Long size;

    @TableField(value = "`share`")
    @ApiModelProperty(value = "")
    private Integer share;

    @TableField(value = "message")
    @ApiModelProperty(value = "")
    private String message;
}