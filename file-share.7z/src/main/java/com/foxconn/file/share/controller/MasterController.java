package com.foxconn.file.share.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.foxconn.file.share.entity.FileBean;
import com.foxconn.file.share.service.FileBeanService;
import com.foxconn.file.share.util.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author X2001077
 * @time 2021/11/2 11:00
 * @description
 */
@Controller
@RequestMapping("/master")
public class MasterController {

    @Value("${file.basePath}")
    private String basePath;

    @Autowired
    private FileBeanService fileBeanService;

    private static final String[] SHOW_TYPES = {"txt", "html", "java", "xml", "properties", "conf"};

    @GetMapping("/{user}/**")
    @PreAuthorize("@ps.hasPermission()")
    public ModelAndView list(HttpServletRequest request, HttpServletResponse response, @PathVariable String user) throws Exception {
        ModelAndView modelAndView = new ModelAndView();
        String dir = FileUtil.getDir(request, user, FileUtil.MASTER_TYPE);
        File file = new File(basePath + user + "/" + dir);
        String path = "";
        if (dir.equals("")) {
            path = "master/" + user + "/";
        } else {
            path = "master/" + user + "/" + dir + "/";
        }
        modelAndView.addObject("path", path);
        modelAndView.addObject("dir", dir);
        modelAndView.addObject("user", user);
        if (!file.exists()) {
            response.sendError(404);
        }
        if (file.isDirectory()) {
            modelAndView.setViewName("index");
            File[] files = file.listFiles();
            List<FileBean> list = new ArrayList<>();
            for (File newFile : files) {
//                FileBean fileBean = new FileBean();
                String sqlPath = user + "/" + dir;
                FileBean fileBean = fileBeanService.getOne(new LambdaQueryWrapper<FileBean>()
                        .eq(FileBean::getOwner, user)
                        .eq(FileBean::getPath, sqlPath)
                        .eq(FileBean::getName, newFile.getName()));
                if (fileBean != null) {
                    fileBean.setPath(path + newFile.getName());
                    list.add(fileBean);
                }
            }
            list.sort((a, b) -> b.getDirectory() - a.getDirectory());
            modelAndView.addObject("files", list);
        } else {
            boolean isShow = false;
            for (String showType : SHOW_TYPES) {
                if (file.getName().substring(file.getName().lastIndexOf(".") + 1).equals(showType)) {
                    isShow = true;
                    break;
                }
            }
            if (isShow) {
                modelAndView.setViewName("show");
                try {
                    FileInputStream fileInputStream = new FileInputStream(file);
                    StringBuilder sb = new StringBuilder();
                    int len;
                    byte[] buffer = new byte[8192];
                    while ((len = fileInputStream.read(buffer)) != -1) {
                        sb.append(new String(buffer, 0, len));
                    }
                    modelAndView.addObject("content", sb.toString());
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                modelAndView.setViewName("download");
                FileBean fileBean = new FileBean();
                String newFileName = file.getName();
                String downloadPath = "";
                if (dir.equals("")) {
                    downloadPath = "/download/" + user + "/";
                } else {
                    downloadPath = "/download/" + user + "/" + dir + "/";
                }
                fileBean.setPath(downloadPath);
                fileBean.setType(newFileName.substring(newFileName.lastIndexOf(".") + 1));
                fileBean.setOwner(user);
                fileBean.setName(newFileName);
                fileBean.setSize(file.length());
                modelAndView.addObject("file", fileBean);
            }

        }
        return modelAndView;
    }

}
