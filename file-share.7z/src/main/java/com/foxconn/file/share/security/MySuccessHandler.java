package com.foxconn.file.share.security;

import com.foxconn.file.share.entity.User;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author X2001077
 * @time 2021/11/2 11:08
 * @description
 */
@Component
public class MySuccessHandler implements AuthenticationSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        Object principal = authentication.getPrincipal();
        String username = "";
        if (principal instanceof User) {
            username = ((User) principal).getUsername();
        }
        String redirectUrl = "/master/" + username;
        response.sendRedirect(redirectUrl);
    }
}
