$(function () {
  /**
   * 初始化分类输入框
   */
  $('#categoryInput').selectize({
    create: true,
    createOnBlur: true,
    maxItems: 10
  });

  /**
   * 新增分类按钮事件
   */
  $('#addCategoryBtn').on('click', function () {
    $.ajax({
      url: "/back/category/",
      data: {"categoryName": $("#categoryInput").val()},
      type: "post",
      dataType: "json",
      success: function (result) {
        if (result.code === 200) {
          layer.msg(result.message, {
            icon: 1, time: 1500, offset: '0px', end: function () {
              $("#addCategoryModal").modal("hide");
              window.location.reload();
            }
          });
        }
      },
      fail: function () {
        layer.msg("新增失败", {
          icon: 4, time: 3000, offset: '0px', end: function () {
            $("#addCategoryModal").modal("hide");
            window.location.reload();
          }
        });
      }
    });
  });
});