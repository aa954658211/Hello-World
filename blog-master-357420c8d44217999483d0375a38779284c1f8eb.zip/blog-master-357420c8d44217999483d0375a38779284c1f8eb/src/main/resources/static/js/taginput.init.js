$(function () {

    /**
     * 初始化标签输入框
     */
    $('#tagInput').selectize({
        create: true,
        createOnBlur: true,
        maxItems: 10
    });

    /**
     * 新增标签按钮事件
     */
    $('#addTagBtn').on('click', function () {
        $.ajax({
            url: "/back/tag/",
            data: {"tagName": $("#tagInput").val()},
            type: "post",
            dataType: "json",
            success: function (result) {
                if (result.code === 200) {
                    layer.msg(result.message, {
                        icon: 1, time: 1500, offset: '0px', end: function () {
                            $("#addTagModal").modal("hide");
                            window.location.reload();
                        }
                    });
                }
            },
            fail: function () {
                layer.msg("新增失败", {
                    icon: 4, time: 3000, offset: '0px', end: function () {
                        $("#addTagModal").modal("hide");
                        window.location.reload();
                    }
                });
            }
        });
    });
});