$(function () {
  $('#skill').selectize({
    create: true,
    createOnBlur: true,
    maxItems: 10
  });

  $('#hobby').selectize({
    create: true,
    createOnBlur: true,
    maxItems: 10
  });
});