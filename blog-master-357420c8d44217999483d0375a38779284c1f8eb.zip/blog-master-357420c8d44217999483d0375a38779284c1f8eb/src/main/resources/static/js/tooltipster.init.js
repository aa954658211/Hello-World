/**
 * 初始化tooltipster插件
 */
$('.tooltips').tooltipster({
  theme: 'tooltipster-borderless'
});