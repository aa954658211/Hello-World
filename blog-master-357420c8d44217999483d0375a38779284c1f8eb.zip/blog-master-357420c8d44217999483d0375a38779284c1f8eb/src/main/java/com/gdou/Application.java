package com.gdou;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author X2001077
 * @time 2021/1/29 上午 11:48
 *  Springboot入口类
 */
@SpringBootApplication
@MapperScan("com.gdou.blog.mapper")
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class,args);
    }
}
