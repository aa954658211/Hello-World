package com.gdou.blog.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdou.blog.entity.Comment;
import com.gdou.blog.entity.Reply;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author X2001077
 * @time 2021/4/6 下午 02:26
 */
public interface CommentMapper extends BaseMapper<Comment> {
    List<Reply> selectReplyBody(@Param("commentId") Integer commentId);
    
    List<Comment> list(@Param("blogId") Integer blogId);
}