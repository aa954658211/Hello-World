package com.gdou.blog.controller;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gdou.blog.entity.ResponseEntity;
import com.gdou.blog.entity.Tag;
import com.gdou.blog.service.TagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author X2001077
 * @time 2021/2/1 下午 03:47
 */
@Controller
@RequestMapping("/back/tag")
public class TagController {
    @Autowired
    TagService tagService;

    @GetMapping("/data")
    @ResponseBody
    public ResponseEntity data(){
        List<Tag> list = tagService.list();
        return ResponseEntity.success().add("list",list);
    }

    @GetMapping("/list")
    public String list(@RequestParam(defaultValue = "1") Integer pageNum,@RequestParam(required = false,defaultValue = "5") Integer pageSize, Model model){
        Page<Tag> page = tagService.page(new Page<>(pageNum, pageSize));
        model.addAttribute("page",page);
        return "tag-mgr";
    }

    @PutMapping("/{tagId}")
    @ResponseBody
    public ResponseEntity update(Tag tag){
        try {
            tagService.update(tag,new LambdaUpdateWrapper<Tag>().eq(Tag::getTagId,tag.getTagId()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.success();
    }


    @DeleteMapping("/{tagId}")
    @ResponseBody
    public ResponseEntity delete(@PathVariable Integer tagId){
        try {
            tagService.removeById(tagId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.success();
    }

    @PostMapping("/")
    @ResponseBody
    public ResponseEntity add(Tag tag){
        try {
            tagService.save(tag);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.success();
    }
}
