package com.gdou.blog.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gdou.blog.entity.Archive;
import com.gdou.blog.entity.Blog;
import com.gdou.blog.entity.Tag;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @author X2001077
 * @time 2021/1/29 下午 02:27
 */
public interface BlogMapper extends BaseMapper<Blog> {
    List<Blog> data();

    Blog getOneById(Integer blogId);

    Page<Blog> page(Page<Blog> page, String title);

    List<Tag> selectTags(Integer blogId);

    List<Tag> selectTags2(Integer blogId,String tagName);

    Page<Blog> pageByCategoryName(Page<Blog> page, String title, String categoryName);

    List<Map<String,Long>> mapCategorys();

    List<Map<String,Long>> mapTags();

    Page<Blog> pageByTagName(Page<Blog> page, @Param("title") String title, @Param("tagName") String tagName);

    List<Archive> getArchives();
}
