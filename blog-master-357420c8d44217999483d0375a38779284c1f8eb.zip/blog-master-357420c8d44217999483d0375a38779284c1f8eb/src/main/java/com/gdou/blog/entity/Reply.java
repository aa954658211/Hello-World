package com.gdou.blog.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 *  @author X2001077
 *   @time 2021/4/6 下午 02:11
*/
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "t_reply")
public class Reply {
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 评论id
     */
    @TableField(value = "comment_id")
    private Integer commentId;

    /**
     * 回复id
     */
    @TableField(value = "reply_id")
    private Integer replyId;

    /**
     * 回复内容
     */
    @TableField(value = "content")
    private String content;

    /**
     * 回复时间
     */
    @TableField(value = "time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date time;

    /**
     * 回复人
     */
    @TableField(value = "reply_name")
    private String replyName;

    /**
     * 被回复人
     */
    @TableField(value = "be_reply_name")
    private String beReplyName;

}