package com.gdou.blog.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author X2001077
 * @time 2021/1/30 上午 09:36
 */
@Controller
@RequestMapping("/back")
public class BackIndexController {

    @GetMapping("/index")
    public String index(){
        return "dashboard";
    }

    @GetMapping("/configuration")
    public String configuration(){
        return "configuration";
    }
}
