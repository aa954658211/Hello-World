package com.gdou.blog.service;

import com.gdou.blog.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;
    /**
 *  @author X2001077
 *   @time 2021/1/29 上午 11:55
*/
public interface UserService extends IService<User>{


}
