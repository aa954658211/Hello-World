package com.gdou.blog.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author X2001077
 * @time 2021/2/2 上午 10:51
 */
@Controller
@RequestMapping("/back/comment")
public class CommentController {

    @GetMapping("/list")
    public String list(){
        return "comment-mgr";
    }
}
