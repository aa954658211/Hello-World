package com.gdou.blog.shiro;

import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.realm.Realm;
import org.apache.shiro.spring.LifecycleBeanPostProcessor;
import org.apache.shiro.spring.security.interceptor.AuthorizationAttributeSourceAdvisor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author X2001077
 * @time 2021/1/29 下午 04:10
 */
@Configuration
public class ShiroConfig {

    @Bean("shiroFilter")
    ShiroFilterFactoryBean shiroFilterFactoryBean(){
        ShiroFilterFactoryBean shiroFilter = new ShiroFilterFactoryBean();
        shiroFilter.setLoginUrl("/login");
        shiroFilter.setSecurityManager(securityManager());

        Map<String,String> chainDefinitionMap = new LinkedHashMap<>();
//        chainDefinitionMap.put("/401","anon");
//        chainDefinitionMap.put("/404","anon");
//        chainDefinitionMap.put("/login","anon");
//        chainDefinitionMap.put("/css/**","anon");
//        chainDefinitionMap.put("/data/**","anon");
//        chainDefinitionMap.put("/img/**","anon");
//        chainDefinitionMap.put("/layer_v3.1.1/**","anon");
//        chainDefinitionMap.put("/js/**","anon");
//        chainDefinitionMap.put("/plugins/**","anon");
//        chainDefinitionMap.put("/upload/**","anon");
        chainDefinitionMap.put("/logout","logout");
        chainDefinitionMap.put("/back/**","authc");
        shiroFilter.setFilterChainDefinitionMap(chainDefinitionMap);//配置拦截规则
        return shiroFilter;
    }

    @Bean
    SecurityManager securityManager(){
        DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
        securityManager.setRealm(realm());
        return securityManager;
    }

    @Bean
    Realm realm(){
        return new MyRealm();
    }


    @Bean
    @DependsOn("lifecycleBeanPostProcessor")
    public DefaultAdvisorAutoProxyCreator defaultAdvisorAutoProxyCreator(){
        DefaultAdvisorAutoProxyCreator defaultAdvisorAutoProxyCreator = new DefaultAdvisorAutoProxyCreator();
        defaultAdvisorAutoProxyCreator.setProxyTargetClass(true);
        return defaultAdvisorAutoProxyCreator;
    }

    @Bean
    public LifecycleBeanPostProcessor lifecycleBeanPostProcessor(){
        return new LifecycleBeanPostProcessor();
    }

    @Bean
    public AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor(SecurityManager securityManager) {
        AuthorizationAttributeSourceAdvisor advisor = new AuthorizationAttributeSourceAdvisor();
        advisor.setSecurityManager(securityManager);
        return advisor;
    }

}
