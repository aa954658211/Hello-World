package com.gdou.blog.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * @author X2001077
 * @time 2021/4/6 下午 02:26
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "t_comment")
public class Comment {
    @TableId(value = "comment_id", type = IdType.AUTO)
    private Integer commentId;

    /**
     * 评论人
     */
    @TableField(value = "reply_name")
    private String replyName;

    /**
     * 评论内容
     */
    @TableField(value = "content")
    private String content;

    /**
     * 评论时间
     */
    @TableField(value = "time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date time;

    /**
     * 评论标题
     */
    @TableField(value = "article_title")
    private String articleTitle;

    /**
     * 操作系统
     */
    @TableField(value = "osname")
    private String osname;

    /**
     * 浏览器
     */
    @TableField(value = "browser")
    private String browser;

    /**
     * 头像URL
     */
    @TableField(value = "img")
    private String img;

    /**
     * 文章id
     */
    @TableField(value = "blog_id")
    private Integer blogId;

    @TableField(exist = false)
    private List<Reply> replyBody;
}