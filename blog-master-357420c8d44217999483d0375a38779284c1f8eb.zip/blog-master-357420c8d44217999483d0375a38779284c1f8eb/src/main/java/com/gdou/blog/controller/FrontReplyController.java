package com.gdou.blog.controller;

import com.gdou.blog.entity.Reply;
import com.gdou.blog.entity.ResponseEntity;
import com.gdou.blog.service.ReplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * @author X2001077
 * @time 2021/4/6 下午 04:10
 */
@RestController
@RequestMapping("/front/reply")
public class FrontReplyController {

    @Autowired
    private ReplyService replyService;

    @PostMapping("/publish")
    public ResponseEntity publish(Reply reply){
        try {
            reply.setTime(new Date());
            replyService.save(reply);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.success().add("reply",reply);
    }
}
