package com.gdou.blog.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gdou.blog.entity.Reply;
import com.gdou.blog.mapper.ReplyMapper;
import com.gdou.blog.service.ReplyService;
/**
 *  @author X2001077
 *   @time 2021/4/6 下午 02:11
*/
@Service
public class ReplyServiceImpl extends ServiceImpl<ReplyMapper, Reply> implements ReplyService{

}
