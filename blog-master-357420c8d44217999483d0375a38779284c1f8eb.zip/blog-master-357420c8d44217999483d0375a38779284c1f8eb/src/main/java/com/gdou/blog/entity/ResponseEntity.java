package com.gdou.blog.entity;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class ResponseEntity {
    private int code;
    private String message;
    private Map<String,Object> data = new HashMap<>();

    public ResponseEntity() {
    }

    public ResponseEntity(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public static ResponseEntity success(){
        ResponseEntity responseBean = new ResponseEntity();
        responseBean.setCode(200);
        responseBean.setMessage("success");
        return responseBean;
    }

    public static ResponseEntity success(int code,String message){
        ResponseEntity responseBean = new ResponseEntity();
        responseBean.setCode(code);
        responseBean.setMessage(message);
        return responseBean;
    }

    public static ResponseEntity fail(){
        ResponseEntity responseBean = new ResponseEntity();
        responseBean.setCode(100);
        responseBean.setMessage("fail");
        return responseBean;
    }

    public ResponseEntity add(String key, Object value){
        this.data.put(key, value);
        return this;
    }
}
