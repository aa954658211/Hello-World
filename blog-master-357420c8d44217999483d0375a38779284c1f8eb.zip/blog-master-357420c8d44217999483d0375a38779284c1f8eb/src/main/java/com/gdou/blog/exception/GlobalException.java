package com.gdou.blog.exception;

import com.gdou.blog.entity.ResponseEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.ShiroException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @author X2001077
 * @time 2021/1/30 上午 08:56
 */
@RestControllerAdvice
@Slf4j
public class GlobalException {

    @ExceptionHandler(ShiroException.class)
    public ResponseEntity handleShiro(ShiroException e){
        return ResponseEntity.fail().add("key",e.getMessage());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity handleGlobal(Exception e){
        return ResponseEntity.fail().add("key",e.getMessage());
    }
}
