package com.gdou.blog.service;

import com.gdou.blog.entity.BlogTag;
import com.baomidou.mybatisplus.extension.service.IService;
    /**
 *  @author X2001077
 *   @time 2021/2/1 下午 03:08
*/
public interface BlogTagService extends IService<BlogTag>{


}
