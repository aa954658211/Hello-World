package com.gdou.blog.util;

import eu.bitwalker.useragentutils.Browser;
import eu.bitwalker.useragentutils.OperatingSystem;
import eu.bitwalker.useragentutils.UserAgent;

import javax.servlet.http.HttpServletRequest;

/**
 * @author X2001077
 * @time 2021/4/6 下午 02:41
 */
public class IpAndAddressUtil {

    /**
     * 获取用户浏览器
     * @param request
     * @return
     */
    public static String getBrowserName(HttpServletRequest request){
        String header = request.getHeader("User-Agent");
        UserAgent userAgent = UserAgent.parseUserAgentString(header);
        Browser browser = userAgent.getBrowser();
        return browser.getName();
    }

    /**
     * 获取用户操作系统
     * @param request
     * @return
     */
    public static String getOsName(HttpServletRequest request){
        String header = request.getHeader("User-Agent");
        UserAgent userAgent = UserAgent.parseUserAgentString(header);
        OperatingSystem operatingSystem = userAgent.getOperatingSystem();
        return operatingSystem.getName();
    }
}
