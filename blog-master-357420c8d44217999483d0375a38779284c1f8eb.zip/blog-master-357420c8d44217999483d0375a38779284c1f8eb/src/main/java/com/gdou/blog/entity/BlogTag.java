package com.gdou.blog.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *  @author X2001077
 *   @time 2021/2/1 下午 03:08
*/
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "t_blog_tag")
public class BlogTag {
    @TableField(value = "blog_id")
    private Integer blogId;

    @TableField(value = "tag_id")
    private Integer tagId;

    @TableId(type = IdType.AUTO)
    private Integer id;

    public BlogTag(Integer blogId, Integer tagId) {
        this.blogId = blogId;
        this.tagId = tagId;
    }
}