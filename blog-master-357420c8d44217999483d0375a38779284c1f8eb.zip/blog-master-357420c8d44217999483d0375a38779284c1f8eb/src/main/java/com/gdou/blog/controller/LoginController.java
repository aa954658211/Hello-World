package com.gdou.blog.controller;

import com.gdou.blog.entity.ResponseEntity;
import com.gdou.blog.entity.User;
import com.gdou.blog.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author X2001077
 * @time 2021/1/29 下午 03:35
 */
@Controller
@RequestMapping("/login")
@Slf4j
public class LoginController {
    @Autowired
    UserService userService;

    @GetMapping
    public String login(){
        return "login";
    }

    @PostMapping
    @ResponseBody
    public ResponseEntity login(User user){
        Subject subject = SecurityUtils.getSubject();
        UsernamePasswordToken token = new UsernamePasswordToken(user.getEmail(),user.getPassword());
        subject.login(token);
        return ResponseEntity.success();
    }
}
