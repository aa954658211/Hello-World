package com.gdou.blog.util;

import com.gdou.blog.entity.User;
import org.apache.shiro.SecurityUtils;

/**
 * @author X2001077
 * @time 2021/2/25 上午 09:27
 */
public class ShiroUtil {

    public static User getCurrentUser(){
        return (User) SecurityUtils.getSubject().getPrincipal();
    }
}
