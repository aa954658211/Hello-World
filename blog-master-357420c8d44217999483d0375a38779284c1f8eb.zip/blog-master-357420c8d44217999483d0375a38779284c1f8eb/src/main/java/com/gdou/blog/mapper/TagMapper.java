package com.gdou.blog.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdou.blog.entity.Tag;

import java.util.List;

/**
 *  @author X2001077
 *   @time 2021/1/29 上午 11:55
*/
public interface TagMapper extends BaseMapper<Tag> {
    List<Tag> findTagByBlogId(Integer blogId);
}