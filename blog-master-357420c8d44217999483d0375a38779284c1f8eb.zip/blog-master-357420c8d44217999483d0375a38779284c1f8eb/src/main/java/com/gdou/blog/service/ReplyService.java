package com.gdou.blog.service;

import com.gdou.blog.entity.Reply;
import com.baomidou.mybatisplus.extension.service.IService;
    /**
 *  @author X2001077
 *   @time 2021/4/6 下午 02:11
*/
public interface ReplyService extends IService<Reply>{


}
