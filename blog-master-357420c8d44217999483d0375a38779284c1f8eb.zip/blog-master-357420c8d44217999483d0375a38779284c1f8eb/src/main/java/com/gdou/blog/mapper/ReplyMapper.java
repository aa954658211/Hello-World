package com.gdou.blog.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdou.blog.entity.Reply;

/**
 *  @author X2001077
 *   @time 2021/4/6 下午 02:11
*/
public interface ReplyMapper extends BaseMapper<Reply> {
}