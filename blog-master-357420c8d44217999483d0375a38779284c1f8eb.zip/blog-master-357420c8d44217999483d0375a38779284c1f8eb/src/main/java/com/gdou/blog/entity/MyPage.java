package com.gdou.blog.entity;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * @author X2001077
 * @time 2021/2/24 下午 01:59
 */
public class MyPage<T>{

    private Page<T> page;

    private long[] navigates;

    private int navigateNums;

    public MyPage(Page<T> page) {
        this(page,5);
    }

    public MyPage(Page<T> page,int navigateNums) {
        this.navigateNums = navigateNums;
        this.navigates = new long[navigateNums];
        this.page = page;
    }

    public long[] getNavigates() {//分三部分,从1-2都是返回前navigateNums页，2-pages-2,从pages-1到pages后navigateNums/2页都是返回后navigateNums页
        long pages = page.getPages();
        long current = page.getCurrent();
        if (pages <= navigateNums){
            for (int i = 0; i < navigateNums; i++) {
                navigates[i] = i+1;
            }
        }else {
            if (current <= (navigateNums/2)){         //当前页数小于导航页数的一半
                for (int i = 0; i < navigateNums; i++) {
                    navigates[i] = i+1;
                }
            }else if (current >= (pages-(navigateNums/2))){ //当前页数大于导航页数的一半
                long temp = pages;
                for (int i = navigateNums - 1; i >= 0 ; i--) {
                    navigates[i] = temp--;
                }
            }else {
                long temp = current-(navigateNums/2);//当前页在中间
                for (int i = 0; i < navigateNums; i++) {
                    navigates[i] = temp++;
                }
            }
        }
        return navigates;
    }

    public void setNavigates(long[] navigates) {
        this.navigates = navigates;
    }
}
