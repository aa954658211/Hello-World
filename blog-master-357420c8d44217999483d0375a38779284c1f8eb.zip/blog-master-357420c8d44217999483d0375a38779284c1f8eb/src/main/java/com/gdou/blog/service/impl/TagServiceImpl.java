package com.gdou.blog.service.impl;

import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gdou.blog.mapper.TagMapper;
import com.gdou.blog.entity.Tag;
import com.gdou.blog.service.TagService;
/**
 *  @author X2001077
 *   @time 2021/1/29 上午 11:55
*/
@Service
public class TagServiceImpl extends ServiceImpl<TagMapper, Tag> implements TagService {

}
