package com.gdou.blog.controller;

import com.gdou.blog.entity.Blog;
import com.gdou.blog.entity.ResponseEntity;
import com.gdou.blog.service.BlogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author X2001077
 * @time 202101/1/30 上午 10:
 */
@RequestMapping("/back/blog")
@Controller
public class BlogController {

    @Autowired
    BlogService blogService;


    @GetMapping("/edit")
    public String edit(){
        return "edit";
    }

    @GetMapping("/{blogId}")
    @ResponseBody
    public ResponseEntity getOne(@PathVariable Integer blogId){
        Blog oneById = blogService.getOneById(blogId);
        return ResponseEntity.success().add("blog",oneById);
    }

    @DeleteMapping("/{blogId}")
    @ResponseBody
    public ResponseEntity delete(@PathVariable Integer blogId){
        blogService.delete(blogId);
        return ResponseEntity.success();
    }

    @DeleteMapping("/deleteAll")
    @ResponseBody
    public ResponseEntity deleteAll(@RequestBody List<Integer> blogIds){
        try {
            blogService.removeByIds(blogIds);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.success(200,"删除成功");
    }

    @GetMapping("/list")
    public String list(){
        return "blog-mgr";
    }

    @GetMapping("/data")
    @ResponseBody
    public Map<String,Object> data(){
        List<Blog> list = blogService.data();
        Map<String,Object> map = new HashMap<>();
        map.put("data",list);
        return map;
    }

    @PostMapping("/saveOrPublish")
    @ResponseBody
    public ResponseEntity saveOrPublish(Blog blog,Integer[] tagId,String flag){
        try {
            blogService.saveOrPublish(blog,tagId,flag);//已经发布的博文不需要再次发布
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.success().add("blogId",blog.getBlogId());
    }

    @PostMapping("/publish")
    @ResponseBody
    public ResponseEntity publish(Integer blogId,String isPublish){
        try {
            Blog blog = new Blog();
            blog.setBlogId(blogId);
            blog.setPublishTime(new Date());
            blog.setIsPublish(isPublish);
            blogService.updateById(blog);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.success();
    }


}
