package com.gdou.blog.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gdou.blog.entity.Archive;
import com.gdou.blog.entity.Blog;
import com.gdou.blog.entity.BlogTag;
import com.gdou.blog.mapper.BlogMapper;
import com.gdou.blog.service.BlogService;
import com.gdou.blog.service.BlogTagService;
import com.gdou.blog.util.ShiroUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 *  @author X2001077
 *   @time 2021/1/29 上午 11:55
*/
@Service
@Transactional(rollbackFor = Exception.class)
public class BlogServiceImpl extends ServiceImpl<BlogMapper, Blog> implements BlogService {

    @Autowired
    BlogTagService blogTagService;

    @Override
    public List<Blog> data() {
        return baseMapper.data();
    }

    @Override
    public Page<Blog> page(Integer pageNum, Integer pageSize, String title) {
        return baseMapper.page(new Page<>(pageNum,pageSize), title);
    }

    @Override
    public boolean saveOrPublish(Blog blog, Integer[] tagId,String flag) {
        boolean result = false;
        blog.setUserId(ShiroUtil.getCurrentUser().getUserId());
        if (StringUtils.isEmpty(blog.getRecommend())){
            blog.setRecommend("off");
        }
        if ("save".equals(flag)){
            result = save(blog,tagId);
        }else if("publish".equals(flag)){
            blog.setPublishTime(new Date());
            result = save(blog,tagId);
        }
        return result;
    }

    @Override
    public boolean save(Blog blog, Integer[] tagId) {
        this.saveOrUpdate(blog);
        List<BlogTag> blogTags = new ArrayList<>();
        //删除之前的关系
        blogTagService.remove(new LambdaQueryWrapper<BlogTag>().eq(BlogTag::getBlogId,blog.getBlogId()));
        for (int i :tagId) {
            blogTags.add(new BlogTag(blog.getBlogId(),i));
        }
        return blogTagService.saveBatch(blogTags);
    }

    @Override
    public Blog getOneById(Integer blogId) {
        return baseMapper.getOneById(blogId);
    }

    @Override
    public boolean delete(Integer blogId) {
        baseMapper.deleteById(blogId);
        return blogTagService.remove(new LambdaQueryWrapper<BlogTag>().eq(BlogTag::getBlogId, blogId));
    }

    @Override
    public Page<Blog> pageByCategoryName(Integer pageNum, Integer pageSize, String title, String categoryName) {
        return baseMapper.pageByCategoryName(new Page<>(pageNum,pageSize),title,categoryName);
    }

    @Override
    public List<Map<String,Long>> mapCategorys() {
        return baseMapper.mapCategorys();
    }

    @Override
    public List<Map<String, Long>> mapTags() {
        return baseMapper.mapTags();
    }

    @Override
    public Page<Blog> pageByTagName(Integer pageNum, Integer pageSize, String title, String tagName) {
        return baseMapper.pageByTagName(new Page<>(pageNum, pageSize), title, tagName);
    }

    @Override
    public List<Archive>   getArchives() {
        return baseMapper.getArchives();
    }
}
