package com.gdou.blog.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gdou.blog.entity.User;
import com.gdou.blog.mapper.UserMapper;
import com.gdou.blog.service.UserService;
import org.springframework.stereotype.Service;

/**
 *  @author X2001077
 *   @time 2021/1/29 上午 11:55
*/
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
}
