package com.gdou.blog.entity;

import lombok.Data;

import java.util.List;

/**
 * @author X2001077
 * @time 2021/4/7 下午 03:44
 */
@Data
public class Archive {
    private String time;
    private List<Blog> blogs;
}
