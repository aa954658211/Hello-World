package com.gdou.blog.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 *  @author X2001077
 *   @time 2021/1/29 上午 11:55
*/
/**
    * 文章表
    */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Blog {
    /**
     * id
     */
    @TableId(value = "blog_id", type = IdType.AUTO)
    private Integer blogId;

    /**
     * 标题
     */
    @TableField(value = "title")
    private String title;

    /**
     * 发表时间
     */
    @TableField(value = "publish_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date publishTime;

    /**
     * 修改时间
     */
    @TableField(value = "modify_time",fill = FieldFill.INSERT_UPDATE)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date modifyTime;

    @TableField(value = "create_time",fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createTime;

    /**
     * 分类id
     */
    @TableField(value = "category_id")
    private Integer categoryId;

    /**
     * 浏览数
     */
    @TableField(value = "view_count")
    private Integer viewCount;

    /**
     * 点赞数
     */
    @TableField(value = "like_count")
    private Integer likeCount;

    /**
     * 描述
     */
    @TableField(value = "description")
    private String description;

    /**
     * 关键字
     */
    @TableField(value = "key_word")
    private String keyWord;

    /**
     * 文章内容
     */
    @TableField(value = "content")
    private String content;

    /**
     * 类型 原创、转载、翻译
     */
    @TableField(value = "creation_type")
    private String creationType;

    /**
     * 是否已经发布
     */
    @TableField(value = "is_publish")
    private String isPublish;

    /**
     * 是否推荐
     */
    @TableField(value = "recommend")
    private String recommend;

    /**
     * 博主id
     */
    @TableField(value = "user_id")
    private Integer userId;


    @TableField(exist = false)
    private Category category;

    @TableField(exist = false)
    private List<Tag> tags;
}