package com.gdou.blog.controller;

import com.gdou.blog.entity.Comment;
import com.gdou.blog.entity.ResponseEntity;
import com.gdou.blog.service.CommentService;
import com.gdou.blog.util.IpAndAddressUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;

/**
 * @author X2001077
 * @time 2021/4/6 下午 02:13
 */
@RestController
@RequestMapping("/front/comment")
public class FrontCommentContorller {
    @Autowired
    private CommentService commentService;

    @PostMapping("/publish")
    public ResponseEntity publish(Comment comment, HttpServletRequest request){
        try {
            comment.setTime(new Date());
            comment.setOsname(IpAndAddressUtil.getOsName(request));
            comment.setBrowser(IpAndAddressUtil.getBrowserName(request));
            commentService.save(comment);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.success().add("comment",comment);
    }

    @GetMapping("/list")
    public ResponseEntity list(Integer blogId){
        List<Comment> list = commentService.list(blogId);
        return ResponseEntity.success().add("comments",list);
    }
}
