package com.gdou.blog.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdou.blog.entity.BlogTag;

/**
 *  @author X2001077
 *   @time 2021/2/1 下午 03:08
*/
public interface BlogTagMapper extends BaseMapper<BlogTag> {
}