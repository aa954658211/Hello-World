package com.gdou.blog.service;

import com.gdou.blog.entity.Comment;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * @author X2001077
 * @time 2021/4/6 下午 02:09
 */
public interface CommentService extends IService<Comment> {
    List<Comment> list(Integer blogId);
}

