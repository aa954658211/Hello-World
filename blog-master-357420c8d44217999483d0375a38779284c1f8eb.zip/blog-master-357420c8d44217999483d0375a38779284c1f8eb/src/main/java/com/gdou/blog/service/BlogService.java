package com.gdou.blog.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.gdou.blog.entity.Archive;
import com.gdou.blog.entity.Blog;

import java.util.List;
import java.util.Map;

/**
 *  @author X2001077
 *   @time 2021/1/29 上午 11:55
*/
public interface BlogService extends IService<Blog>{

    List<Blog> data();

    Page<Blog> page(Integer pageNum,Integer pageSize,String title);

    boolean saveOrPublish(Blog blog,Integer[] tagId,String flag);

    boolean save(Blog blog,Integer[] tagId);


    Blog getOneById(Integer blogId);

    boolean delete(Integer blogId);

    Page<Blog> pageByCategoryName(Integer pageNum, Integer pageSize, String title, String categoryName);

    List<Map<String,Long>> mapCategorys();

    List<Map<String,Long>> mapTags();

    Page<Blog> pageByTagName(Integer pageNum, Integer pageSize, String title, String tagName);

    List<Archive>  getArchives();
}
