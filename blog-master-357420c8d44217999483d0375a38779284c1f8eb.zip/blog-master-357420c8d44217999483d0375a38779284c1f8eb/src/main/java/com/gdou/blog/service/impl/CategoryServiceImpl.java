package com.gdou.blog.service.impl;

import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gdou.blog.mapper.CategoryMapper;
import com.gdou.blog.entity.Category;
import com.gdou.blog.service.CategoryService;
/**
 *  @author X2001077
 *   @time 2021/1/29 上午 11:55
*/
@Service
public class CategoryServiceImpl extends ServiceImpl<CategoryMapper, Category> implements CategoryService {

}
