package com.gdou.blog.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gdou.blog.entity.Archive;
import com.gdou.blog.entity.Blog;
import com.gdou.blog.entity.MyPage;
import com.gdou.blog.entity.ResponseEntity;
import com.gdou.blog.service.BlogService;
import com.gdou.blog.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @author X2001077
 * @time 2021/2/18 上午 11:34
 */
@Controller
public class FrontIndexController {

    @Autowired
    private BlogService blogService;
    @Autowired
    private CategoryService categoryService;

    @GetMapping("/")
    public String index(){
        return "forward:/front/index";
    }

    @GetMapping("/front/index")
    public String index(@RequestParam(defaultValue = "1") Integer pageNum, @RequestParam(required = false,defaultValue = "5") Integer pageSize, String title,Model model){
        Page<Blog> page = blogService.page(pageNum,pageSize,title);
        model.addAttribute("page",page);
        return "index";
    }

    @GetMapping("/front/blog/{blogId}")
    public String detail(@PathVariable Integer blogId,Model model){
        Blog oneById = blogService.getOneById(blogId);
        model.addAttribute("blog",oneById);
        return "detail";
    }

    @PostMapping("/front/category/data")
    @ResponseBody
    public ResponseEntity categorys(){
        List<Map<String,Long>> categorys = blogService.mapCategorys();
        return ResponseEntity.success().add("categorys",categorys);
    }

    @GetMapping("/front/category/list")
    public String listCategory(){
        return "category";
    }

    @PostMapping("/front/category/list")
    @ResponseBody
    public ResponseEntity listCategory(@RequestParam(defaultValue = "1") Integer pageNum, @RequestParam(required = false,defaultValue = "5") Integer pageSize, String title,String categoryName){
        Page<Blog> page = blogService.pageByCategoryName(pageNum,pageSize,title,categoryName);
        MyPage<Blog> myPage = new MyPage<>(page);
        return ResponseEntity.success().add("page",page).add("navigates",myPage.getNavigates());
    }

    @PostMapping("/front/tag/data")
    @ResponseBody
    public ResponseEntity tags(){
        List<Map<String, Long>> maps = blogService.mapTags();
        return ResponseEntity.success().add("tags",maps);
    }

    @GetMapping("/front/tag/list")
    public String listTag(){
        return "tag";
    }

    @PostMapping("/front/tag/list")
    @ResponseBody
    public ResponseEntity listTat(@RequestParam(defaultValue = "1") Integer pageNum, @RequestParam(required = false,defaultValue = "5") Integer pageSize, String title,String tagName){
        Page<Blog> page = blogService.pageByTagName(pageNum,pageSize,title,tagName);
        MyPage<Blog> myPage = new MyPage<>(page);
        return ResponseEntity.success().add("page",page).add("navigates",myPage.getNavigates());
    }

    @GetMapping("/front/archive/list")
    public String archive(Model model){
        List<Archive>   archives = blogService.getArchives();
        model.addAttribute("archives",archives);
        return "archive";
    }


    @GetMapping("/front/guestbook/list")
    public String guestbook(){
        return "guestbook";
    }
}
