package com.gdou.blog.controller;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gdou.blog.entity.Category;
import com.gdou.blog.entity.ResponseEntity;
import com.gdou.blog.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author X2001077
 * @time 2021/2/1 下午 03:36
 */
@Controller
@RequestMapping("/back/category")
public class CategoryController {
    @Autowired
    CategoryService categoryService;

    @GetMapping("/data")
    @ResponseBody
    public ResponseEntity data(){
        List<Category> list = categoryService.list();
        return ResponseEntity.success().add("list",list);
    }

    @GetMapping("/list")
    public String list(@RequestParam(defaultValue = "1") Integer pageNum, @RequestParam(required = false,defaultValue = "5") Integer pageSize, Model model){
        Page<Category> page = categoryService.page(new Page<>(pageNum, pageSize));
        model.addAttribute("page",page);
        return "category-mgr";
    }

    @PutMapping("/{categoryId}")
    @ResponseBody
    public ResponseEntity update(Category category){
        try {
            categoryService.update(category,new LambdaUpdateWrapper<Category>().eq(Category::getCategoryId,category.getCategoryId()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.success();
    }


    @DeleteMapping("/{categoryId}")
    @ResponseBody
    public ResponseEntity delete(@PathVariable Integer categoryId){
        try {
            categoryService.removeById(categoryId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.success();
    }

    @PostMapping("/")
    @ResponseBody
    public ResponseEntity add(Category category){
        try {
            categoryService.save(category);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.success();
    }
}
