package com.gdou;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gdou.blog.entity.Blog;
import com.gdou.blog.entity.MyPage;
import com.gdou.blog.service.BlogService;
import com.gdou.blog.service.CategoryService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;

/**
 * @author X2001077
 * @time 2021/1/29 下午 02:19
 */
@SpringBootTest(classes = Application.class)
@RunWith(SpringRunner.class)
public class SqlTest {

    @Autowired
    CategoryService categoryService;
    @Autowired
    BlogService blogService;

    @Test
    public void test1(){
        System.out.println(categoryService.getById(1));
    }

    @Test
    public void test2(){
//        System.out.println(blogService.mapTags());
        Page<Blog> spring = blogService.pageByTagName(5, 1, null, "JAVA");
        MyPage<Blog> myPage = new MyPage<>(spring);
        System.out.println(Arrays.toString(myPage.getNavigates()));
    }
}
