package com.gdou;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class Test<T> {

    T t;

    public Test(T t) {
        this.t = t;
    }

    public static <T> T[] toArray(T... t){
        System.out.println(t.getClass().getName());
        return t;
    }
    public void test(){
        System.out.println(t);
    }
    public static <T> T[] pickTwo(T t1,T t2,T t3) {
        return toArray(t1,t2);
    }
    public static void main(String[] args) throws Exception {
        Test<String> test = new Test<>("43");
        Method test1 = test.getClass().getDeclaredMethod("test");
        test.getClass().getDeclaredMethod("pickTwo", Object.class, Object.class, Object.class).invoke(String.class,1,2,3);
        test.pickTwo("123","34234","324234");
        List<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.getClass().getMethod("add", Object.class).invoke(list,"qwe");
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
    }
}
