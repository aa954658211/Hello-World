package com.gdou.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdou.bean.FileBean;

public interface FileBeanMapper extends BaseMapper<FileBean> {
}
