package com.gdou.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gdou.bean.FileBean;
import com.gdou.bean.MyPage;
import com.gdou.service.FileBeanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ResourceUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.concurrent.TimeUnit;

@Controller
public class FileBeanController {
    @Autowired
    private FileBeanService fileBeanService;
    private String fileName;

    public File getRealPath() {
        File folder = null;
        try {
            File path = new File(ResourceUtils.getURL("classpath:").getPath());
            folder = new File(path.getAbsolutePath(),"static/file");
            if (!folder.exists()) {
                folder.mkdirs();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return folder;
    }

    public String uploadFile(MultipartFile file){
        FileBean fileBean = fileBeanService.getOne(new QueryWrapper<FileBean>().eq("name", file.getOriginalFilename()));
        if (fileBean !=null || file.isEmpty())
            return "文件已存在或者文件为空";
        File folder = getRealPath();
        System.out.println(folder.getAbsolutePath());
        String type = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".") + 1);
        try {
            long start = System.nanoTime();
            file.transferTo(new File(folder, file.getOriginalFilename()));
            long end = System.nanoTime();
            FileBean fileBean1 = new FileBean();
            fileBean1.setName(file.getOriginalFilename());
            fileBean1.setType(type);
            fileBean1.setCount(0);
            fileBean1.setTimeCost(TimeUnit.NANOSECONDS.toMillis(end-start));
            fileBean1.setSize(file.getSize());
            fileBeanService.save(fileBean1);
        } catch (Exception e) {
            return "failed";
        }
        return "success";
    }

    @PostMapping("/upload")
    @ResponseBody
    public String upload(MultipartFile[] files) {
        String s = null;
        for (MultipartFile file : files) {
            s = uploadFile(file);
            if (s.equals("文件已存在或者文件为空") || s.equals("failed"))
                return s;
        }
        return s;
    }

    @GetMapping("/")
    public String index2(){
        return "forward:/index/1/5";
    }


    @GetMapping("/index")
    public String index1(){
        return "forward:/index/1/5";
    }

    @GetMapping("/index/{pageNum}/{size}")
    public String index(@PathVariable Integer pageNum, @PathVariable Integer size, Model model,String fileName,Integer flag){
        if ( StringUtils.isEmpty(pageNum))
            pageNum = 1;
        if ( StringUtils.isEmpty(size))
            pageNum = 5;
        LambdaQueryWrapper<FileBean> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.orderByDesc(FileBean::getId);
        if (!StringUtils.isEmpty(fileName)){
            lambdaQueryWrapper.like(FileBean::getName,fileName);
            this.fileName = fileName;
        } else{//从搜索框进来的应该是跟之前相关的,如果是空值应该查所有,并且清空缓存的filename，否则就是上次搜索的结果
            if (flag != null){
                lambdaQueryWrapper = null;
                this.fileName = null;
            }else {
                if (!StringUtils.isEmpty(this.fileName))
                    lambdaQueryWrapper.like(FileBean::getName,this.fileName);
            }
        }
        Page<FileBean> page = fileBeanService.page(new Page<>(pageNum, size), lambdaQueryWrapper);
        MyPage<FileBean> myPage = new MyPage<>(page);
        model.addAttribute("myPage",myPage);
        return "index";
    }

    @GetMapping("/download/{filename}")
    @ResponseBody
    public void download(@PathVariable String filename,HttpServletResponse response) throws UnsupportedEncodingException {
        File file = new File(getRealPath(),filename);
        if (file.exists()){
//            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition","attachment;filename="
                    +new String(filename.getBytes("utf-8"),"ISO8859-1"));
            byte[] buff = new byte[1024];
            InputStream inputStream = null;
            BufferedOutputStream bos = null;
            OutputStream outputStream = null;
            try {
                outputStream = response.getOutputStream();
                inputStream = new FileInputStream(file);
                bos = new BufferedOutputStream(outputStream);
                int read = -1;
                while ((read = inputStream.read(buff))!=-1){
                    bos.write(buff);
                    bos.flush();
                }
            //增加下载次数
                FileBean one = fileBeanService.getOne(new QueryWrapper<FileBean>().eq("name", filename));
                one.setCount(one.getCount()+1);
                fileBeanService.updateById(one);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    bos.close();
                    inputStream.close();
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @GetMapping("/delete/{filename}")
    @ResponseBody
    public String deleteByName(@PathVariable String filename){
        File file = new File(getRealPath(),filename);
        if (file.exists()){
            file.delete();
            fileBeanService.remove(new QueryWrapper<FileBean>().eq("name",filename));
            return "删除成功";
        }
        return "删除失败";
    }


}
