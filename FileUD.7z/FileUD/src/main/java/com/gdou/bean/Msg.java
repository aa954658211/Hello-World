package com.gdou.bean;

import java.util.HashMap;
import java.util.Map;

public class Msg {
    private int code;
    private String message;
    private Map<String,Object> data = new HashMap<>();

    private Msg(){}

    public static Msg success(){
        Msg msg = new Msg();
        msg.setCode(200);
        msg.setMessage("success");
        return msg;
    }
    public static Msg fail(){
        Msg msg = new Msg();
        msg.setCode(100);
        msg.setMessage("fail");
        return msg;
    }

    public  Msg add(String key,Object value){
        this.data.put(key,value);
        return this;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }
}
