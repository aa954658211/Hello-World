package com.gdou.bean;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@ToString
public class MyPage<T> {
    private Long navigateNum;
    private List<Long> navigateNums;
    private Page<T> page;
    public MyPage(Page<T> page) {
        this.page = page;
        this.navigateNum = page.getCurrent();
        List<Long> list = new ArrayList<>();
        //总页数小于等于5的，和总页数大于5的情况
        if (page.getPages() <= 5){
            for (int i = 1; i <= page.getPages(); i++) {
                list.add((long) i);
            }
        }else{
            if (navigateNum < 3){                       //1 2 返回1 2 3 4 5 (都是返回这5页),前两页不变
                for (int i = 1; i <= 5; i++) {
                    list.add((long) i);
                }
            }else if (navigateNum >= 3 && navigateNum < page.getPages()-2){  //后两页不变
                for (int i = 2; i > 0; i--) {
                    list.add(navigateNum-i);
                }
                for (Long i = navigateNum; i < navigateNum+3; i++){
                    list.add(i);
                }
            }else {
                for (Long i = page.getPages()-4; i <= page.getPages(); i++) {
                    list.add(i);
                }
            }
        }
        this.navigateNums = list;
    }

    public Long getNavigateNum() {
        return navigateNum;
    }


    public List<Long> getNavigateNums() {
        return navigateNums;
    }

    public Page<T> getPage() {
        return page;
    }
}
