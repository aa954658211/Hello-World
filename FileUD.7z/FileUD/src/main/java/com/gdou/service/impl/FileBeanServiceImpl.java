package com.gdou.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gdou.bean.FileBean;
import com.gdou.mapper.FileBeanMapper;
import com.gdou.service.FileBeanService;
import org.springframework.stereotype.Service;

@Service
public class FileBeanServiceImpl extends ServiceImpl<FileBeanMapper, FileBean> implements FileBeanService {
}
