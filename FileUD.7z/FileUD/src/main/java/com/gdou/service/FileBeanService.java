package com.gdou.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdou.bean.FileBean;

public interface FileBeanService extends IService<FileBean> {
}
