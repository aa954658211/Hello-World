package com.foxconn.xml;

import com.foxconn.config.Configuration;
import com.foxconn.config.Datasource;
import com.foxconn.model.Table;
import org.apache.commons.digester3.Digester;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;

/**
 * @author X2001077
 * @time 2021/4/29 下午 04:37
 */
public class XMLGeneratorBuilder {

    private InputStream inputStream;

    public XMLGeneratorBuilder(InputStream inputStream) {
        this.inputStream = inputStream;
    }

    public Configuration parse() {
        Digester digester = new Digester();
        Configuration configuration = null;
        digester.setValidating(false);
        //添加根节点configuration
        digester.addObjectCreate("configuration", Configuration.class);
        digester.addSetProperties("configuration");

        digester.addObjectCreate("configuration/datasource", Datasource.class);
        //添加DataSource属性
        digester.addSetProperties("configuration/datasource");
        digester.addSetNext("configuration/datasource", "addDatasource");

        digester.addBeanPropertySetter("configuration/basePath");
        digester.addBeanPropertySetter("configuration/entityPackage");

        digester.addObjectCreate("configuration/table", Table.class);
        digester.addBeanPropertySetter("configuration/table/tableName");
        digester.addBeanPropertySetter("configuration/table/pojoName");
        //将table添加到list
        digester.addSetNext("configuration/table", "addTable");

        try {
            configuration = (Configuration) digester.parse(inputStream);

        } catch (IOException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        }
        return configuration;
    }
}
