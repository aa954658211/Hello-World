package com.foxconn.model;

/**
 * @author X2001077
 * @time 2021/4/30 上午 08:29
 */
public class Table {
    private String tableName;
    private String pojoName;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getPojoName() {
        return pojoName;
    }

    public void setPojoName(String pojoName) {
        this.pojoName = pojoName;
    }
}
