package com.foxconn.model;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author X2001077
 * @time 2021/4/27 下午 04:08
 */
public class PojoModel {
    private String pojoName;
    private String pojoComment;
    private String pojoPackage;
    private List<PojoField> list;
    private Set<String> importClass;

    public PojoModel addImportClass(String clazz){
        if (importClass == null) {
            importClass = new HashSet<>();
        }
        importClass.add(clazz);
        return this;
    }

    public Set<String> getImportClass() {
        return importClass;
    }

    public void setImportClass(Set<String> importClass) {
        this.importClass = importClass;
    }

    public String getPojoPackage() {
        return pojoPackage;
    }

    public void setPojoPackage(String pojoPackage) {
        this.pojoPackage = pojoPackage;
    }

    public String getPojoName() {
        return pojoName;
    }

    public void setPojoName(String pojoName) {
        this.pojoName = pojoName;
    }

    public String getPojoComment() {
        return pojoComment;
    }

    public void setPojoComment(String pojoComment) {
        this.pojoComment = pojoComment;
    }

    public List<PojoField> getList() {
        return list;
    }

    public void setList(List<PojoField> list) {
        this.list = list;
    }

    @Override
    public String toString() {
        return "PojoModel{" +
                "pojoName='" + pojoName + '\'' +
                ", pojoComment='" + pojoComment + '\'' +
                ", list=" + list +
                '}';
    }
}
