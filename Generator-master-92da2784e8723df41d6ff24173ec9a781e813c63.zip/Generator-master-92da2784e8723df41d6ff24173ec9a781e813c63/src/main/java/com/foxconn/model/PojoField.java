package com.foxconn.model;

/**
 * @author X2001077
 * @time 2021/4/27 下午 04:12
 */
public class PojoField {
    private String modify;
    private String type;
    private Class<?> typeClass;
    private String name;
    private String comment;
    private String camelName;

    public String getCamelName() {
        return camelName;
    }

    public void setCamelName(String camelName) {
        this.camelName = camelName;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getModify() {
        return modify;
    }

    public void setModify(String modify) {
        this.modify = modify;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Class<?> getTypeClass() {
        return typeClass;
    }

    public void setTypeClass(Class<?> typeClass) {
        this.typeClass = typeClass;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "PojoField{" +
                "modify='" + modify + '\'' +
                ", type='" + type + '\'' +
                ", typeClass=" + typeClass +
                ", name='" + name + '\'' +
                ", comment='" + comment + '\'' +
                '}';
    }
}
