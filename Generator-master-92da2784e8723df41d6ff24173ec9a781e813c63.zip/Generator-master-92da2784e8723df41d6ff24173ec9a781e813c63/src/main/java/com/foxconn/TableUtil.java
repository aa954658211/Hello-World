package com.foxconn;

import com.foxconn.config.Configuration;
import com.foxconn.config.TableGenerator;
import com.foxconn.config.ThymeleafConfig;
import com.foxconn.model.PojoField;
import com.foxconn.model.PojoModel;
import com.foxconn.model.Table;
import com.foxconn.util.JdbcTypeMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author X2001077
 * @time 2021/4/27 上午 11:45
 */
public class TableUtil {

    public static String getByPattern(String pattern, String sql, int group) {
        Pattern p = Pattern.compile(pattern);
        Matcher matcher = p.matcher(sql);
        if (matcher.find()) {
            return matcher.group(group);
        }
        return null;
    }

    public static String getTableName(String sql) {
        String table = getByPattern("CREATE TABLE `(.*)`", sql, 1);
        if (table != null) {
            return table;
        }
        return null;
    }

    public static String getTableComment(String sql) {
        String comment = getByPattern("\\).* COMMENT='(.*)'", sql, 1);
        if (comment != null) {
            return comment;
        }
        return null;
    }

    /**
     * 获取表的每一行字段名的
     *
     * @param sql
     * @return
     */
    public static List<String> getTableFiled(String sql) {
        List<String> list = new ArrayList<>();
        Scanner scanner = new Scanner(sql);
        while (scanner.hasNext()) {
            String line = scanner.nextLine();
            if (line.contains("CREATE TABLE")) {
                continue;
            } else if (line.contains("ENGINE") || line.contains("PRIMARY KEY")) {
                continue;
            } else {
                list.add(line);
            }
        }
        return list;
    }

    public static String getTableCamel(String tableName) {
        return getCamel(tableName, true);
    }

    /**
     * 转驼峰
     *
     * @param str
     * @param flag
     * @return
     */
    public static String getCamel(String str, boolean flag) {
        char[] chars = str.toLowerCase().toCharArray();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < chars.length; i++) {
            if (flag && (chars[i] >= 'a' && chars[i] <= 'z')) {
                char newChar = (char) (chars[i] - 32);
                sb.append(newChar);
                flag = false;
            } else if (chars[i] == '_') {
                flag = true;
                continue;
            } else {
                sb.append(chars[i]);
            }
        }
        return sb.toString();
    }

    public static String getFiledCamel(String filedName) {
        return getCamel(filedName, false);
    }

    /**
     * 获取表实际的字段名
     *
     * @param sql
     * @param group
     * @return
     */
    public static PojoField getTableFiled(String sql, int group) {
        String columnName = getByPattern("`(.*)`", sql, group);
        String commentName = getByPattern("COMMENT ('.*')", sql, group);
        if (commentName == null) {
            commentName = columnName;
        }
        //只限制英文字符不会匹配到空格
        String columnType = getByPattern(columnName + "` ([a-zA-Z]*)", sql, group);
        PojoField pojoField = new PojoField();
        pojoField.setModify("private");
        pojoField.setComment(commentName);
        pojoField.setName(getFiledCamel(columnName));
        pojoField.setCamelName(getTableCamel(columnName));
        Class<?> aClass = new JdbcTypeMapping().getClass(columnType);
        pojoField.setTypeClass(aClass);
        pojoField.setType(aClass.getSimpleName());
        return pojoField;
    }

    public static File getPath(String basePath, String entityPackage, String className) {
        entityPackage = entityPackage.replaceAll("\\.", "/") + "/";
        if (!basePath.endsWith("/")) {
            basePath += "/";
        }
        if (!basePath.startsWith("/")) {
            basePath = "/" + basePath;
        }
        String parentPath = System.getProperty("user.dir") + basePath + entityPackage;
        File file = new File(parentPath, className + ".java");
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
        return file;
    }

    public static void generate(TableGenerator tableGenerator) {
        Logger logger = LoggerFactory.getLogger(TableUtil.class);
        logger.info("Start generate entity--------------------->");

        Connection connection = null;
        try {
            connection = tableGenerator.getConnection();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        Configuration configuration = tableGenerator.getConfiguration();
        List<Table> tables = configuration.getTables();
        if (!tables.isEmpty()) {
            logger.info("开始生成总共{}个表的实体类文件", tables.size());
            int i = 0;
            TemplateEngine templateEngine = ThymeleafConfig.getTemplateEngine();
            for (Table table : tables) {
                logger.info("开始生成表名{},实体类名{}", table.getTableName(), table.getPojoName());
                try {
                    PreparedStatement statement = connection.prepareStatement("show create table " + table.getTableName());
                    ResultSet resultSet = statement.executeQuery();
                    while (resultSet.next()) {
                        String tableColumn = resultSet.getString(2);
//                String tableName = getTableName(tableColumn);
                        String tableComment = getTableComment(tableColumn);
                        if (tableComment == null) {
                            tableComment = table.getTableName();
                        }
                        PojoModel model = new PojoModel();
                        if ("".equals(table.getPojoName())) {
                            model.setPojoName(getTableCamel(table.getTableName()));
                        } else {
                            model.setPojoName(table.getPojoName());
                        }
                        model.setPojoComment(tableComment);
                        model.setPojoPackage(configuration.getEntityPackage());
                        List<PojoField> list = new ArrayList<>();
                        model.setList(list);
                        List<String> tableFiled = getTableFiled(tableColumn);
                        for (String s : tableFiled) {
                            PojoField filed = getTableFiled(s, 1);
                            list.add(filed);
                            model.addImportClass(filed.getTypeClass().getName());
                        }

                        Context context = new Context(Locale.CHINA);
                        context.setVariable("model", model);
                        String process = templateEngine.process("java/model.txt", context);
                        Writer writer = new FileWriter(getPath(configuration.getBasePath(), configuration.getEntityPackage(), model.getPojoName()));
                        writer.write(process);
                        logger.info("第{}个表生成完成", ++i);
                        writer.close();
                    }

                } catch (SQLException e) {
                    logger.error(e.getMessage());
                    e.printStackTrace();
                } catch (IOException e) {
                    logger.error("实体类{}生成失败", table.getPojoName());
                    e.printStackTrace();
                }
            }
        }
    }


}
