package com.foxconn.config;

import com.foxconn.TableUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author X2001077
 * @time 2021/4/29 下午 04:35
 */
public class TableGenerator {
    private Configuration configuration;

    private Connection connection;

    public TableGenerator() {
    }

    public TableGenerator(Configuration configuration) {
        this.configuration = configuration;
    }

    public Connection getConnection() throws SQLException, ClassNotFoundException {
        if (connection == null) {
            Datasource dataSource = this.configuration.getDataSource();
            Class.forName(dataSource.getDriver());
            connection = DriverManager.getConnection(dataSource.getUrl(),dataSource.getUser(),dataSource.getPassword());
        }
        return connection;
    }

    public void generate()  {
        TableUtil.generate(this);
        close();
    }

    public void close(){
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public Configuration getConfiguration() {
        return configuration;
    }

    public void setConfiguration(Configuration configuration) {
        this.configuration = configuration;
    }
}
