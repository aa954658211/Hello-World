package com.foxconn.config;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;
import org.thymeleaf.templateresolver.ITemplateResolver;

import java.util.Collections;

/**
 * @author X2001077
 * @time 2021/4/28 上午 09:58
 */
public class ThymeleafConfig {
    static class InitTplConfig{
        final static TemplateEngine TEMPLATE_ENGINE = new TemplateEngine();

        static TemplateEngine getTemplateEngine(){
            return TEMPLATE_ENGINE;
        }
    }

    public static TemplateEngine getTemplateEngine(){
        TemplateEngine templateEngine = InitTplConfig.getTemplateEngine();
        templateEngine.addTemplateResolver(textTemplateEngine());
        return templateEngine;
    }

    private static ITemplateResolver textTemplateEngine() {
        final ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
        templateResolver.setOrder(1);
        templateResolver.setResolvablePatterns(Collections.singleton("java/*"));
        templateResolver.setPrefix("/template/");
        templateResolver.setSuffix(".txt");
        templateResolver.setTemplateMode(TemplateMode.TEXT);
        templateResolver.setCharacterEncoding("utf-8");
        templateResolver.setCacheable(false);
        return templateResolver;
    }
}
