package com.foxconn.config;

import com.foxconn.xml.XMLGeneratorBuilder;

import java.io.InputStream;

/**
 * @author X2001077
 * @time 2021/4/29 下午 04:32
 */
public class TableGeneratorFactory {

    public TableGenerator build(String generatorPath) {
        InputStream inputStream = this.getClass().getResourceAsStream(generatorPath);
        if (inputStream == null) {
            inputStream = this.getClass().getClassLoader().getResourceAsStream(generatorPath);
        }
        return build(inputStream);
    }

    public TableGenerator build(InputStream inputStream) {
        XMLGeneratorBuilder builder = new XMLGeneratorBuilder(inputStream);
        return build(builder.parse());
    }

    public TableGenerator build(Configuration configuration) {
        return new TableGenerator(configuration);
    }

}
