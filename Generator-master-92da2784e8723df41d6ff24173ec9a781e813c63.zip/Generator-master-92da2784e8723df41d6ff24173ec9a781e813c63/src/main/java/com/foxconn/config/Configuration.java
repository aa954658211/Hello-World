package com.foxconn.config;

import com.foxconn.model.Table;

import java.util.ArrayList;
import java.util.List;

/**
 * @author X2001077
 * @time 2021/4/29 下午 03:03
 */
public class Configuration {
    private Datasource datasource;
    private List<Table> tables = new ArrayList<>();
    private String basePath;
    private String entityPackage;

    public List<Table> getTables() {
        return tables;
    }

    public void setTables(List<Table> tables) {
        this.tables = tables;
    }

    public void addDatasource(Datasource datasource) {
        this.datasource = datasource;
    }

    public void addTable(Table table) {
        this.tables.add(table);
    }

    public Datasource getDataSource() {
        return datasource;
    }

    public void setDataSource(Datasource dataSource) {
        this.datasource = dataSource;
    }


    public String getBasePath() {
        return basePath;
    }

    public void setBasePath(String basePath) {
        this.basePath = basePath;
    }

    public String getEntityPackage() {
        return entityPackage;
    }

    public void setEntityPackage(String entityPackage) {
        this.entityPackage = entityPackage;
    }
}
