package com.foxconn.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author X2001077
 * @time 2021/4/27 下午 04:23
 */
public class JdbcTypeMapping {

    private Map<String,Class<?>> map = new HashMap<>();
    {
        map.put("byte",Byte.class);
        map.put("char",String.class);
        map.put("short",Short.class);
        map.put("int",Integer.class);
        map.put("bigint",Integer.class);
        map.put("long",Long.class);
        map.put("boolean",boolean.class);
        map.put("double",Double.class);
        map.put("float",Float.class);
        map.put("varchar",String.class);
        map.put("datetime", Date.class);
        map.put("timestamp", Date.class);
        map.put("text", String.class);
    }

    public Class<?> getClass(String jdbcType){
        if (map.get(jdbcType) == null) {
            jdbcType = jdbcType.toLowerCase();
        }
        return map.get(jdbcType);
    }
}
