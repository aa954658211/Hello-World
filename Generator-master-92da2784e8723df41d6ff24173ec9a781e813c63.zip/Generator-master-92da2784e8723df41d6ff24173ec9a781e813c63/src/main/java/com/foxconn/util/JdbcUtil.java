package com.foxconn.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * @author X2001077
 * @time 2021/4/27 上午 11:47
 */
public class JdbcUtil {
    private static  Connection connection;
    private static Properties jdbcProperties;
    static {
        try {
            jdbcProperties = new Properties();
            jdbcProperties.load(JdbcUtil.class.getClassLoader().getResourceAsStream("jdbc.properties"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection(){
        return getConnection(jdbcProperties.getProperty("jdbc.url"),
                jdbcProperties.getProperty("jdbc.username"),jdbcProperties.getProperty("jdbc.password"));
    }

    public static String getBasePath(){
        return jdbcProperties.getProperty("base.path");
    }

    public static String getEntityPackage(){
        return jdbcProperties.getProperty("entity.package");
    }

    public static Connection getConnection(String url,String username,String password){
        if (connection != null) {
            return connection;
        }
        try {
            connection = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }


}
