package com.foxconn.entity;


import java.util.Date;
import java.lang.String;
import java.lang.Integer;


/**
 * @author hyh
 * apn_user
 */
public class ApnUser{
    
    /**
     * id
     */
    private Integer id;
    /**
     * username
     */
    private String username;
    /**
     * password
     */
    private String password;
    /**
     * email
     */
    private String email;
    /**
     * name
     */
    private String name;
    /**
     * created_date
     */
    private Date createdDate;
    /**
     * update_date
     */
    private Date updateDate;
    /**
     * online
     */
    private Date online;
    /**
     * updated_date
     */
    private Date updatedDate;
    
    
    public void setId(Integer id){
       this.id = id;
    }

    public Integer getId(){
        return this.id;
    }

    public void setUsername(String username){
       this.username = username;
    }

    public String getUsername(){
        return this.username;
    }

    public void setPassword(String password){
       this.password = password;
    }

    public String getPassword(){
        return this.password;
    }

    public void setEmail(String email){
       this.email = email;
    }

    public String getEmail(){
        return this.email;
    }

    public void setName(String name){
       this.name = name;
    }

    public String getName(){
        return this.name;
    }

    public void setCreatedDate(Date createdDate){
       this.createdDate = createdDate;
    }

    public Date getCreatedDate(){
        return this.createdDate;
    }

    public void setUpdateDate(Date updateDate){
       this.updateDate = updateDate;
    }

    public Date getUpdateDate(){
        return this.updateDate;
    }

    public void setOnline(Date online){
       this.online = online;
    }

    public Date getOnline(){
        return this.online;
    }

    public void setUpdatedDate(Date updatedDate){
       this.updatedDate = updatedDate;
    }

    public Date getUpdatedDate(){
        return this.updatedDate;
    }

    
}