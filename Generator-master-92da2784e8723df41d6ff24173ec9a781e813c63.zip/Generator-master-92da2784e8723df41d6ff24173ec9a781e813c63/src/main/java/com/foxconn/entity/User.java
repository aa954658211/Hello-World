package com.foxconn.entity;


import java.lang.String;
import java.lang.Integer;


/**
 * @author hyh
 * user
 */
public class User{
    
    /**
     * id
     */
    private Integer id;
    /**
     * name
     */
    private String name;
    /**
     * age
     */
    private Integer age;
    /**
     * gender
     */
    private String gender;
    
    
    public void setId(Integer id){
       this.id = id;
    }

    public Integer getId(){
        return this.id;
    }

    public void setName(String name){
       this.name = name;
    }

    public String getName(){
        return this.name;
    }

    public void setAge(Integer age){
       this.age = age;
    }

    public Integer getAge(){
        return this.age;
    }

    public void setGender(String gender){
       this.gender = gender;
    }

    public String getGender(){
        return this.gender;
    }

    
}