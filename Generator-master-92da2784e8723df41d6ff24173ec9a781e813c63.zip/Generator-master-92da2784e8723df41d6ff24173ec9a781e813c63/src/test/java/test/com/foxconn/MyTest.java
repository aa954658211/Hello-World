package test.com.foxconn;

import com.foxconn.config.TableGenerator;
import com.foxconn.config.TableGeneratorFactory;
import org.junit.Test;

/**
 * @author X2001077
 * @time 2021/4/27 上午 11:45
 */
public class MyTest {

    @Test
    public void method(){
        TableGenerator tableGenerator = new TableGeneratorFactory().build("generator.xml");
        tableGenerator.generate();
    }
}
